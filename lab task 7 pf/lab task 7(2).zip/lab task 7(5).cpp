#include <iostream>
using namespace std;

int main() 
{
  
    int arr[6] = {10, 20, 30, 40, 50, 60};
    int i = 5;
    do
    {
        
        cout << arr[i] << " ";
         i--;
    } while (i >= 0); 
  
}

